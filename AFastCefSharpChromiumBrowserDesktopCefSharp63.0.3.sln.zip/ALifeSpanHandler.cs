﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CefSharp;
using CefSharp.WinForms;


namespace ChromiumApplication
{
  //  public class LifeSpanHandler : ILifeSpanHandler { }
      //  private string url;

        // open popup in new tab!
     //   public bool OnBeforePopup(IWebBrowser browserTabControl, IBrowser browser, IFrame frame, string targetUrl, string targetFrameName, WindowOpenDisposition targetDisposition, bool userGesture, IPopupFeatures popupFeatures, IWindowInfo windowInfo, IBrowserSettings browserSettings, ref bool noJavascriptAccess, out IWebBrowser ChromiumWebBrowser)  { ChromiumWebBrowser = myForm.NewPage(targetUrl); return true; }


      //  public virtual bool OnBeforePopup(IWebBrowser browser, string sourceUrl, string targetUrl, ref int x, ref int y, ref int width, ref int height) { return true;  }

      //  public virtual void OnBeforeClose(IWebBrowser browser) { // DO NOTHING }


}