﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_OS_Forms_Application.Handler.Example.Customize.Request
{
    public class Path
    {
        public static object ChromiumApplication { get; internal set; }

        internal static string GetExtension(string fileName)
        {
            throw new NotImplementedException();
        }

        internal static string GetDirectoryName(string executablePath)
        {
            throw new NotImplementedException();
        }
    }
}

namespace Win_OS_Forms_Application.Handler.Example.Customize.Request
    {
    internal class account
    {
        public static string id { get; internal set; }
    }
    class args
    {
        public static string Title { get; internal set; }
    }
}



