﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_OS_Forms_Application.Object
    {
    public class JsSerializableClass
    {
        public string Value { get; set; }
    }
}
