﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_OS_Forms_Application.Object
    {
    class Class__
        {

        //Environment.SetEnvironmentVariable("GOOGLE_API_KEY", "AIzaSyBS-qjz0jmK4jvZy06Rq4DLs0_AITqo7lw");
        //Environment.SetEnvironmentVariable("GOOGLE_DEFAULT_CLIENT_ID", "888034971568-kmdju8hjiem3mqqi3kgjmals6p0l0te4.apps.googleusercontent.com");
        //Environment.SetEnvironmentVariable("GOOGLE_DEFAULT_CLIENT_SECRET", "6fa_ZYlY8KxDd_KDOz1SdENV");


        }
    }
